title: 🎨适用于Bolo的高级主题 ---- Fantastic | 移植自Halo主题
date: '2020-04-06 14:55:53'
updated: '2020-04-06 15:10:34'
tags: [Bolo, JavaScript]
permalink: /articles/2020/04/06/1586156153265.html
---
![5c401ed7e7bce70476b6d7d1.jpg](https://img.hacpai.com/file/2020/04/5c401ed7e7bce70476b6d7d1-067a1513.jpg)

## ✨

摸鱼式爆肝接近一星期，基本搞定了
仓库地址 [https://github.com/csfwff/bolo-fantastic](https://github.com/csfwff/bolo-fantastic)
感谢 Halo 主题 Fantastic 作者 imkundev ：[Halo 主题 Fantastic✨](https://github.com/imkundev/halo-theme-fantastic)
感谢 Bolo 作者 [adlered](https://github.com/adlered) 在开发中提供技术支持

## 使用方法

1. clone 到本地
2. 丢进 bolo 的 skins 文件夹
3. 刷新一下下

注：暂不支持 Solo（主要是偷懒了……）

## 预览图

可以点[这里](https://sszsj.top/?skin=bolo-fantastic)看看实际效果
是否暗黑模式跟随浏览器自动切换
![image.png](https://img.hacpai.com/file/2020/04/image-1936d6c4.png)
![null](https://github.com/adlered/bolo-solo/raw/master/preview/3.png)

## 注意

1. 皮肤不支持 pjax，请自行评估是否使用
2. bolo_v1.6 已内置该皮肤

## 最后

FreeMarker 一点也不 free
