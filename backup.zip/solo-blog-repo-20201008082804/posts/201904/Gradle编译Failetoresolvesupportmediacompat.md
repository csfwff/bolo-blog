title: Gradle编译 Faile to resolve:support-media-compat
date: '2019-04-09 13:41:48'
updated: '2019-12-09 12:31:12'
tags: [Andorid, Gradle]
permalink: /articles/2019/04/09/1554788508900.html
---
![QQ截图20190409110406.png](https://img.hacpai.com/file/2019/04/QQ截图20190409110406-41a263b6.png)
 原因是中央仓库里没找到相应的包
解决方案是在项目的build.gradle中
```
allprojects {
    repositories {
        google()
        jcenter()
    }
}
```

把google挪到jcenter前就可以了
